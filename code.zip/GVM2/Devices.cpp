#include "Devices.h"

Module Devices::module;
OpenGLDevice Devices::draw;
collide Devices::collide;
physic Devices::physic;
BehaviorActivate Devices::behavior;
animplay Devices::anime;
