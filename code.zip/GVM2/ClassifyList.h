#pragma once
#include<vector>
#include<unordered_map>
#include<string>
#include<tuple>
class Object;
class ClassifyList
{
public:
	ClassifyList();
	Object* head[6];
	//βָ��ָ��β���
	Object* tail[6];
	std::unordered_map<std::string, Object*> names;
	std::vector<std::tuple<Object*,int>>delList;
	void add(Object* obj, int classify);
	//����ɾ���б�
	void del(Object* node, int classify);
	void del(std::string name, int classify);
	bool noUse(Object* node);
	void deleteNode(Object* del, int classify);
	//����
	void recycle();
	Object* begin(int c);
	Object* end(int c);
	~ClassifyList() {}
};

