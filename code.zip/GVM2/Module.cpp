#include "Module.h"
#include"Object.h"
std::vector<Intersect> Module::intersect_list;
std::vector<std::string>  Module::objects_name;
ClassifyList Module::CList;
void Module::add(Object* object)
{
	CList.add(object,NO_DEVICE);

}
