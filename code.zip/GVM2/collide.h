#pragma once
#include<glm/glm.hpp>
#include"Intersect.h"
#include"Module.h"
#include<vector>
#include"Object.h"
#include<iostream>
#include"collide2D.h"
using namespace std;
using namespace glm;

class collide : public Module
{
public:
	collide() {}

	virtual void add(Object* object)
	{
		CList.add(object,COLLIDE_DEVICE);
	}
	virtual void Collide()
	{
		for (Object* i = CList.begin(COLLIDE_DEVICE); i != nullptr; i = i->next[COLLIDE_DEVICE])
		{
			
			for (Object* j = i; j != nullptr; j = j->next[COLLIDE_DEVICE])
			{
				Object* obj1 = i;
				Object* obj2 = j;
				if (obj1 == obj2)
					continue;
				if (obj1->inClassify(PHY_DEVICE) || obj2->inClassify(PHY_DEVICE))
				{
					
					if (Collide2D(intersect_list, obj1, obj2))
					{
						obj1->elementStartState(&intersect_list.back(), obj2, &CList);
						obj2->elementStartState(&intersect_list.back(), obj1, &CList);
					}
						
				}
			}
		}
	}
	~collide() {}
};

