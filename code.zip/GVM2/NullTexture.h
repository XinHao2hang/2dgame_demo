#pragma once
#include"Texture.h"
template<class TEXTURE>
class NullTexture:public Texture<TEXTURE>
{
public:
	NullTexture() {}
	virtual TEXTURE loadTexture(vector<string> filename)
	{
		return -1;
	}
	~NullTexture() {}
};

