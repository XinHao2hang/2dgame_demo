#include "animplay.h"
#include"Object.h"
#include<GLFW/glfw3.h>
void animplay::run()
{
	double now = glfwGetTime();
	double delta = now - lastTime;
	lastTime = now;
	accumulator += delta;
	for (Object* i = CList.begin(ANIM_DEVICE); i != nullptr; i = i->next[ANIM_DEVICE])
	{
		i->playAnim(clock);
	}
	if (accumulator > 0.15)
	{
		clock++;
		accumulator = 0;
	}
	if (clock == 100)
		clock = 0;
}
