#pragma once

class InputObject
{
public:
	//static GLFWwindow* window;
	InputObject(){}
	virtual void setKeyBoardInput()
	{

		//glfwSetKeyCallback(window, key_callback);
	}
	~InputObject() {}
};

