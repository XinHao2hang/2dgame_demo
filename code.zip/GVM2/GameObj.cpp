#include "GameObj.h"



GameObj::GameObj()
{
}


GameObj::~GameObj()
{
}
