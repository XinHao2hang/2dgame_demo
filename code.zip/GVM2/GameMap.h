#pragma once
#include"GameObj.h"
struct MapBlock
{
	string obj;
	vec3 pos;
	vec3 size;
};
class GameMap
{
public:
	//��ͼԪ��
	MapBlock map[20][20];
	int width, height;

	GameMap();
	~GameMap();
};

