#pragma once
#include"Factory.h"
#include<algorithm>
#include<iostream>
#include"physic.h"
#include"OpenGLDevice.h"
#include"devices.h"

struct Index
{
	int i=0, j=0;
	Index(int _i, int _j):i(_i),j(_j) {}
	~Index(){}
	bool operator==(const Index& t)const
	{
		return t.i == i && t.j == j;
	}

};
struct HashFun
{
	std::size_t operator()(const Index& key) const
	{
		return std::hash<int>()(key.i*10000+key.j);
	}
};

class map
{
	void addBufferList(int i, int j, GameBlockObject* ele)
	{
		ele->i = i;
		ele->j = j;
		ele->inMap = true;
		ele->mapPtr = this;
		bufferList.push_back(make_tuple(i, j, ele));
	}
public:
	//��ͼԪ��
	unordered_map<Index, GameBlockObject*,HashFun> mapElements;
	vec3 position = vec3(-800,-800,0);
	GameBlockObject* select;
	static map* tMap;
	static double px, py;
	std::vector<Module*> tmodules;
	//�����б�
	vector<tuple<int,int,GameBlockObject*>> bufferList;

	
	void setBufferList()
	{
		//����ͼԪ�ؼ���
		for (unsigned long i = 0; i < bufferList.size(); i++)
		{
			//Ԫ�ؼ���������
			for(unsigned long k = 0;k<tmodules.size();k++)
				tmodules[k]->add(get<2>(bufferList[i]));
			if (get<2>(bufferList[i])->animPlay.size() > 0)
			{
				Devices::anime.add(get<2>(bufferList[i]));
			}
			//������ײ��
			makeCollideLine(get<0>(bufferList[i]), get<1>(bufferList[i]));
			makeCollideLine(get<0>(bufferList[i])-1, get<1>(bufferList[i]));
			makeCollideLine(get<0>(bufferList[i])+1, get<1>(bufferList[i]));
			makeCollideLine(get<0>(bufferList[i]), get<1>(bufferList[i])-1);
			makeCollideLine(get<0>(bufferList[i]), get<1>(bufferList[i])+1);
		}
		bufferList.clear();
	}
	void makeCollideLine(int i, int j)
	{
		if (i < 0 || i >= 50)
			return;
		if (j < 0 || j >= 50)
			return;
		//���û�д�Ԫ�أ�ֱ�ӷ���
		if (mapElements.find(Index(i, j)) == mapElements.end())
			return;
		//����ײ���͹�0
		mapElements[Index(i,j)]->collideType = 0;
		//��
		if ((i + 1 < 50 && mapElements.find(Index(i + 1,j)) == mapElements.end()))
			mapElements[Index(i,j)]->collideType |= TOP;
		//��
		if ((i - 1 >= 0 && mapElements.find(Index(i - 1,j)) == mapElements.end()))
			mapElements[Index(i, j)]->collideType |= BOTTOM;
		//��
		if ((j - 1 >= 0 && mapElements.find(Index(i,j - 1)) == mapElements.end()))
			mapElements[Index(i, j)]->collideType |= LEFT;
		//��
		if ((j + 1 < 50 && mapElements.find(Index(i,j + 1)) == mapElements.end()))
			mapElements[Index(i, j)]->collideType |= RIGHT;
	}
	void setInput(GLFWwindow* window)
	{
		//glfwSetKeyCallback(window, key_callback);
		tMap = this;
	
		glfwSetCursorPosCallback(window, cursor_position_callback);
		glfwSetMouseButtonCallback(window, mouse_button_callback);
	}
	static void cursor_position_callback(GLFWwindow* window, double x, double y)
	{
		px = floor((2 * x - 800+40)/80);
		px =px* 80;
		py = ceil((-2 * y + 800-40) / 80);
		py = py * 80;
		tMap->select->setPosture(vec3(px,py,0),glm::vec3(0,0,0));
	}
	static void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
	{
		GameBlockObject* a;
		int i = 0,j = 0;
		if (action == GLFW_PRESS) switch (button)
		{
		case GLFW_MOUSE_BUTTON_LEFT:
			i = (int)((px - 40-tMap->position.x) / 80.0f);
			j = (int)((py + 40-tMap->position.y) / 80.0f);
			//����һ���µĿ�
			a = Factory("HatenaObject")(to_string(i * 10000 + j), glm::vec3(80, 80, 0), glm::vec3(j*80, i*80, 0),glm::vec3(0,0,0));
			if (!tMap->addElement(j, i + 1, a))
				delete a;
			break;
		case GLFW_MOUSE_BUTTON_MIDDLE:
			break;
		case GLFW_MOUSE_BUTTON_RIGHT:
			i = (int)((px - 40 - tMap->position.x) / 80.0f);
			j = (int)((py + 40 - tMap->position.y) / 80.0f);
			tMap->deleteElement(j,i+1);
			break;
		default:
			return;
		}
		return;
	}

	map(){}
	bool addElement(int i, int j, GameBlockObject* obj)
	{
		if (obj == nullptr)
			return false;
		if (i < 0 || j < 0)
			return false;
		//���ж��ظ�����
		if (mapElements.find(Index(i, j)) != mapElements.end())
			return false;
		mapElements[Index(i,j)] = obj;
		obj->setPosture(vec3(position.x + j * 80, position.y + i * 80, 0), glm::vec3(0,0,0));
		addBufferList(i,j,mapElements[Index(i,j)]);
		return true;
	}
	bool deleteElement(int i, int j)
	{
		//�ж�Ԫ���Ƿ����
		if (mapElements.find(Index(i, j)) == mapElements.end())
			return false;
		//�Ը������ɾ��
		Devices::module.CList.del(mapElements[Index(i,j)]->objName, DRAW_DEVICE);
		Devices::module.CList.del(mapElements[Index(i,j)]->objName, PHY_DEVICE);
		Devices::module.CList.del(mapElements[Index(i,j)]->objName, COLLIDE_DEVICE);
		Devices::module.CList.del(mapElements[Index(i, j)]->objName, BEHAVE_DEVICE);
		Devices::module.CList.del(mapElements[Index(i, j)]->objName, ANIM_DEVICE);
		//��Ԫ�ؼ�¼�ӵ�ͼ��ɾ��
		mapElements.erase(Index(i,j));
		//������ײ��
		makeCollideLine(i - 1, j);
		makeCollideLine(i + 1, j);
		makeCollideLine(i, j - 1);
		makeCollideLine(i, j + 1);
		return true;
	}

	virtual void set(std::vector<Module*> modules)
	{
		tmodules = modules;
	}

};

