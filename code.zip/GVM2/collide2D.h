#pragma once
#include"collide2D.h"
#include"Object.h"
#include"Intersect.h"
#include<algorithm>
struct crossPoint
{
	bool vaild = false;
	vec3 point = vec3(0, 0, 0);
};

static crossPoint lineCrossPoint(vec3 a, vec3 b, vec3 c, vec3 d)
{
	float theta = 0;
	crossPoint point;
	//a,b�Ǻ���
	//c,d������
	if (a.x + theta <= c.x && c.x <= b.x - theta)
		point.point.x = c.x;
	else
	{
		point.vaild = false;
		return point;
	}
	if (d.y + theta <= a.y && a.y <= c.y - theta)
	{
		point.point.y = a.y;
	}
	else
	{
		point.vaild = false;
		return point;
	}
	point.vaild = true;
	return point;
}

static bool Collide2D(std::vector<Intersect>& list, Object* A, Object* B)
{
	//������ײ
	if (A->collideType == BOX || B->collideType == BOX)
	{
		//��AΪ��
		if (A->collideType != BOX)
		{
			swap(A, B);
		}
		vec3 Ar = A->r / 2.0f;
		vec3 Br = B->r / 2.0f;
		//����߷�Χ
		vec3 minExtentsA = (A->position - Ar);
		vec3 maxExtentsA = (A->position + Ar);
		vec3 minExtentsB = (B->position - Br);
		vec3 maxExtentsB = (B->position + Br);

		//���������ཻ����
		glm::vec3 distances1 = minExtentsA - maxExtentsB;
		glm::vec3 distances2 = minExtentsB - maxExtentsA;
		glm::vec3 distances = glm::vec3(distances1.x > distances2.x ? distances1.x : distances2.x, distances1.y > distances2.y ? distances1.y : distances2.y, 0);
		float maxDistance = distances.x > distances.y ? distances.x : distances.y;
		bool res = false;
		if (maxDistance >= 0)
			return res;
		//�����ཻ��ķ���������Ϊû����ת�����Բ���Ҫ������
		glm::vec3 n = glm::vec3(0, 0, 0);
		if (maxDistance == distances.x)
			n = glm::vec3(1, 0, 0);
		else
			n = glm::vec3(0, 1, 0);

		//������ײ��

		float apx = A->position.x + Ar.x;
		float anx = A->position.x - Ar.x;
		float apy = A->position.y + Ar.y;
		float any = A->position.y - Ar.y;
		vec3 Aa = vec3(anx, apy, 0);
		vec3 Ab = vec3(apx, apy, 0);
		vec3 Ac = vec3(anx, any, 0);
		vec3 Ad = vec3(apx, any, 0);

		float bpx = B->position.x + Br.x;
		float bnx = B->position.x - Br.x;
		float bpy = B->position.y + Br.y;
		float bny = B->position.y - Br.y;
		vec3 Ba = vec3(bnx, bpy, 0);
		vec3 Bb = vec3(bpx, bpy, 0);
		vec3 Bc = vec3(bnx, bny, 0);
		vec3 Bd = vec3(bpx, bny, 0);

		crossPoint pat[4] = { 0 }, pbt[4] = { 0 }, p[2] = { 0 };
		vec3 pa = vec3(0, 0, 0);
		vec3 pb = vec3(0, 0, 0);
		//����
		if (B->collideType == TOPLINE)
		{
			//B������A����������
			pbt[0] = lineCrossPoint(Ba, Bb, Aa, Ac);
			pbt[2] = lineCrossPoint(Ba, Bb, Ab, Ad);
			if (pbt[0].vaild || pbt[2].vaild)
			{
				pa = pbt[0].point;
				pb = pbt[2].point;
				n = vec3(0, 1, 0) * directVec(B->position - A->position);
				if (pbt[0].vaild)
				{
					list.push_back(Intersect(maxDistance < 0, maxDistance, n, pa, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
					res = true;
				}
				if (pbt[2].vaild)
				{
					list.push_back(Intersect(maxDistance < 0, maxDistance, n, pb, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
					res = true;
				}
			}
			else
				return false;
		}
		//����
		else if (B->collideType == BOTTOMLINE)
		{
			pbt[1] = lineCrossPoint(Bc, Bd, Aa, Ac);
			pbt[3] = lineCrossPoint(Bc, Bd, Ab, Ad);
			if (pbt[1].vaild || pbt[3].vaild)
			{
				pa = pbt[1].point;
				pb = pbt[3].point;
				n = vec3(0, 1, 0) * directVec(B->position - A->position);
				if (pbt[1].vaild)
				{
					list.push_back(Intersect(maxDistance < 0, maxDistance, n, pa, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
					res = true;
				}
				if (pbt[3].vaild)
				{
					list.push_back(Intersect(maxDistance < 0, maxDistance, n, pb, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
					res = true;
				}
			}
			else
				return false;
		}
		//����
		else if (B->collideType == LEFTLINE)
		{
			pat[1] = lineCrossPoint(Aa, Ab, Ba, Bc);
			pat[3] = lineCrossPoint(Ac, Ad, Ba, Bc);
			if (pat[1].vaild || pat[3].vaild)
			{
				pa = pat[1].point;
				pb = pat[3].point;
			}
			n = vec3(1, 0, 0) * directVec(B->position - A->position);
			if (pat[1].vaild)
			{
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, pa, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			if (pat[3].vaild)
			{
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, pb, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
		}
		//����
		else if (B->collideType == RIGHTLINE)
		{
			pat[0] = lineCrossPoint(Aa, Ab, Bb, Bd);
			pat[2] = lineCrossPoint(Ac, Ad, Bb, Bd);
			if (pat[0].vaild || pat[2].vaild)
			{
				pa = pat[0].point;
				pb = pat[2].point;
			}
			n = vec3(1, 0, 0) * directVec(B->position - A->position);
			if (pat[0].vaild)
			{
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, pa, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			if (pat[2].vaild)
			{
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, pb, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
		}
		//����˫��
		else if (B->collideType == DOUBLE_YLINE)
		{
			pat[0] = lineCrossPoint(Aa, Ab, Bb, Bd);
			pat[1] = lineCrossPoint(Aa, Ab, Ba, Bc);
			pat[2] = lineCrossPoint(Ac, Ad, Bb, Bd);
			pat[3] = lineCrossPoint(Ac, Ad, Ba, Bc);
			if (pat[0].vaild || pat[1].vaild || pat[2].vaild || pat[3].vaild)
			{
				if (pat[0].vaild)
					pa = pat[0].point;
				else if (pat[2].vaild)
					pb = pat[2].point;

				if (pat[1].vaild)
					pa = pat[1].point;
				else if (pat[3].vaild)
					pb = pat[3].point;

				n = vec3(1, 0, 0) * directVec(B->position - A->position);
				if (pat[0].vaild || pat[1].vaild)
				{
					list.push_back(Intersect(maxDistance < 0, maxDistance, n, pa, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
					res = true;
				}
				if (pat[2].vaild || pat[3].vaild)
				{
					list.push_back(Intersect(maxDistance < 0, maxDistance, n, pb, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
					res = true;
				}
			}
		}
		//˫����
		else if (B->collideType == DOUBLE_XLINE)
		{
			pbt[0] = lineCrossPoint(Ba, Bb, Aa, Ac);
			pbt[1] = lineCrossPoint(Bc, Bd, Aa, Ac);
			pbt[2] = lineCrossPoint(Ba, Bb, Ab, Ad);
			pbt[3] = lineCrossPoint(Bc, Bd, Ab, Ad);
			if (pbt[0].vaild || pbt[1].vaild || pbt[2].vaild || pbt[3].vaild)
			{
				if (pbt[0].vaild)
					pa = pbt[0].point;
				else if (pbt[2].vaild)
					pb = pbt[2].point;

				if (pbt[1].vaild)
					pa = pbt[1].point;
				else if (pbt[3].vaild)
					pb = pbt[3].point;

				n = vec3(0, 1, 0) * directVec(B->position - A->position);
				if (pbt[0].vaild || pbt[1].vaild)
				{
					list.push_back(Intersect(maxDistance < 0, maxDistance, n, pa, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
					res = true;
				}
				if (pbt[2].vaild || pbt[3].vaild)
				{
					list.push_back(Intersect(maxDistance < 0, maxDistance, n, pb, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
					res = true;
				}
			}
		}
		//��ȱ��
		else if (B->collideType == CLEFT)
		{
			pat[0] = lineCrossPoint(Aa, Ab, Bb, Bd);
			//pat[1] = lineCrossPoint(Aa, Ab, Ba, Bc);
			pat[2] = lineCrossPoint(Ac, Ad, Bb, Bd);
			//pat[3] = lineCrossPoint(Ac, Ad, Ba, Bc);

			pbt[0] = lineCrossPoint(Ba, Bb, Aa, Ac);
			pbt[1] = lineCrossPoint(Bc, Bd, Aa, Ac);
			pbt[2] = lineCrossPoint(Ba, Bb, Ab, Ad);
			pbt[3] = lineCrossPoint(Bc, Bd, Ab, Ad);
			crossPoint p[4];
			int k = 0;
			for (int i = 0; i < 4; i++)
			{
				if (pbt[i].vaild)
				{
					p[k] = pbt[i];
					k++;
				}
				if (k >= 2)
					break;
				if (pat[i].vaild)
				{
					p[k] = pat[i];
					k++;
				}
				if (k >= 2)
					break;
			}
			if (k == 1)
			{
				n = vec3(0, 1, 0) * directVec(B->position - A->position);
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[0].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			else if (k == 2)
			{
				n = n * directVec(B->position - A->position);
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[0].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[1].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			else
				return false;
		}
		//��ȱ��
		else if (B->collideType == CRIGHT)
		{
			//pat[0] = lineCrossPoint(Aa, Ab, Bb, Bd);
			pat[1] = lineCrossPoint(Aa, Ab, Ba, Bc);
			//pat[2] = lineCrossPoint(Ac, Ad, Bb, Bd);
			pat[3] = lineCrossPoint(Ac, Ad, Ba, Bc);

			pbt[0] = lineCrossPoint(Ba, Bb, Aa, Ac);
			pbt[1] = lineCrossPoint(Bc, Bd, Aa, Ac);
			pbt[2] = lineCrossPoint(Ba, Bb, Ab, Ad);
			pbt[3] = lineCrossPoint(Bc, Bd, Ab, Ad);
			crossPoint p[2];
			int k = 0;
			for (int i = 0; i < 4; i++)
			{
				if (pbt[i].vaild)
				{
					p[k] = pbt[i];
					k++;
				}
				if (k >= 2)
					break;
				if (pat[i].vaild)
				{
					p[k] = pat[i];
					k++;
				}
				if (k >= 2)
					break;
			}
			if (k == 1)
			{
				n = vec3(0, 1, 0) * directVec(B->position - A->position);
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[0].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			else if (k == 2)
			{
				n = n * directVec(B->position - A->position);
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[0].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[1].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			else
				return false;
		}
		//��ȱ��
		else if (B->collideType == CTOP)
		{
			pat[0] = lineCrossPoint(Aa, Ab, Bb, Bd);
			pat[1] = lineCrossPoint(Aa, Ab, Ba, Bc);
			pat[2] = lineCrossPoint(Ac, Ad, Bb, Bd);
			pat[3] = lineCrossPoint(Ac, Ad, Ba, Bc);

			//pbt[0] = lineCrossPoint(Ba, Bb, Aa, Ac);
			pbt[1] = lineCrossPoint(Bc, Bd, Aa, Ac);
			//pbt[2] = lineCrossPoint(Ba, Bb, Ab, Ad);
			pbt[3] = lineCrossPoint(Bc, Bd, Ab, Ad);
			crossPoint p[2];
			int k = 0;
			for (int i = 0; i < 4; i++)
			{
				if (pbt[i].vaild)
				{
					p[k] = pbt[i];
					k++;
				}
				if (k >= 2)
					break;
				if (pat[i].vaild)
				{
					p[k] = pat[i];
					k++;
				}
				if (k >= 2)
					break;
			}
			if (k == 1)
			{
				n = vec3(1, 0, 0) * directVec(B->position - A->position);
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[0].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			else if (k == 2)
			{
				n = n * directVec(B->position - A->position);
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[0].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[1].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			else
				return false;
		}
		//��ȱ��
		else if (B->collideType == CBOTTOM)
		{
			pat[0] = lineCrossPoint(Aa, Ab, Bb, Bd);
			pat[1] = lineCrossPoint(Aa, Ab, Ba, Bc);
			pat[2] = lineCrossPoint(Ac, Ad, Bb, Bd);
			pat[3] = lineCrossPoint(Ac, Ad, Ba, Bc);

			pbt[0] = lineCrossPoint(Ba, Bb, Aa, Ac);
			//pbt[1] = lineCrossPoint(Bc, Bd, Aa, Ac);
			pbt[2] = lineCrossPoint(Ba, Bb, Ab, Ad);
			//pbt[3] = lineCrossPoint(Bc, Bd, Ab, Ad);

			int k = 0;
			for (int i = 0; i < 4; i++)
			{
				if (pbt[i].vaild)
				{
					p[k] = pbt[i];
					k++;
				}
				if (k >= 2)
					break;
				if (pat[i].vaild)
				{
					p[k] = pat[i];
					k++;
				}
				if (k >= 2)
					break;
			}
			if (k == 1)
			{
				n = vec3(1, 0, 0) * directVec(B->position - A->position);
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[0].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			else if (k == 2)
			{
				n = n * directVec(B->position - A->position);
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[0].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[1].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			else
				return false;
		}
		//����L
		else if (B->collideType == LLEFTTOP)
		{
			//pat[0] = lineCrossPoint(Aa, Ab, Bb, Bd);
			pat[1] = lineCrossPoint(Aa, Ab, Ba, Bc);
			//pat[2] = lineCrossPoint(Ac, Ad, Bb, Bd);
			pat[3] = lineCrossPoint(Ac, Ad, Ba, Bc);

			pbt[0] = lineCrossPoint(Ba, Bb, Aa, Ac);
			//pbt[1] = lineCrossPoint(Bc, Bd, Aa, Ac);
			pbt[2] = lineCrossPoint(Ba, Bb, Ab, Ad);
			//pbt[3] = lineCrossPoint(Bc, Bd, Ab, Ad);

			int k = 0;
			for (int i = 0; i < 4; i++)
			{
				if (pbt[i].vaild)
				{
					p[k] = pbt[i];
					k++;
				}
				if (k >= 2)
					break;
				if (pat[i].vaild)
				{
					p[k] = pat[i];
					k++;
				}
				if (k >= 2)
					break;
			}
			if (k == 1)
			{
				n = n * directVec(B->position - A->position);
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[0].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			else if (k == 2)
			{
				n = n * directVec(B->position - A->position);
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[0].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[1].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			else
				return false;
		}
		//����L
		else if (B->collideType == LRIGHTTOP)
		{
			pat[0] = lineCrossPoint(Aa, Ab, Bb, Bd);
			//pat[1] = lineCrossPoint(Aa, Ab, Ba, Bc);
			pat[2] = lineCrossPoint(Ac, Ad, Bb, Bd);
			//pat[3] = lineCrossPoint(Ac, Ad, Ba, Bc);

			pbt[0] = lineCrossPoint(Ba, Bb, Aa, Ac);
			//pbt[1] = lineCrossPoint(Bc, Bd, Aa, Ac);
			pbt[2] = lineCrossPoint(Ba, Bb, Ab, Ad);
			//pbt[3] = lineCrossPoint(Bc, Bd, Ab, Ad);

			int k = 0;
			for (int i = 0; i < 4; i++)
			{
				if (pbt[i].vaild)
				{
					p[k] = pbt[i];
					k++;
				}
				if (k >= 2)
					break;
				if (pat[i].vaild)
				{
					p[k] = pat[i];
					k++;
				}
				if (k >= 2)
					break;
			}
			if (k == 1)
			{
				n = n * directVec(B->position - A->position);
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[0].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			else if (k == 2)
			{
				n = n * directVec(B->position - A->position);
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[0].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[1].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			else
				return false;
		}
		//����L
		else if (B->collideType == LLEFTBOTTOM)
		{
			//pat[0] = lineCrossPoint(Aa, Ab, Bb, Bd);
			pat[1] = lineCrossPoint(Aa, Ab, Ba, Bc);
			//pat[2] = lineCrossPoint(Ac, Ad, Bb, Bd);
			pat[3] = lineCrossPoint(Ac, Ad, Ba, Bc);

			//pbt[0] = lineCrossPoint(Ba, Bb, Aa, Ac);
			pbt[1] = lineCrossPoint(Bc, Bd, Aa, Ac);
			//pbt[2] = lineCrossPoint(Ba, Bb, Ab, Ad);
			pbt[3] = lineCrossPoint(Bc, Bd, Ab, Ad);

			int k = 0;
			for (int i = 0; i < 4; i++)
			{
				if (pbt[i].vaild)
				{
					p[k] = pbt[i];
					k++;
				}
				if (k >= 2)
					break;
				if (pat[i].vaild)
				{
					p[k] = pat[i];
					k++;
				}
				if (k >= 2)
					break;
			}
			if (k == 1)
			{
				n = n * directVec(B->position - A->position);
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[0].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			else if (k == 2)
			{
				n = n * directVec(B->position - A->position);
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[0].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[1].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			else
				return false;
		}
		//����L
		else if (B->collideType == LRIGHTBOTTOM)
		{
			pat[0] = lineCrossPoint(Aa, Ab, Bb, Bd);
			//pat[1] = lineCrossPoint(Aa, Ab, Ba, Bc);
			pat[2] = lineCrossPoint(Ac, Ad, Bb, Bd);
			//pat[3] = lineCrossPoint(Ac, Ad, Ba, Bc);

			//pbt[0] = lineCrossPoint(Ba, Bb, Aa, Ac);
			pbt[1] = lineCrossPoint(Bc, Bd, Aa, Ac);
			//pbt[2] = lineCrossPoint(Ba, Bb, Ab, Ad);
			pbt[3] = lineCrossPoint(Bc, Bd, Ab, Ad);

			int k = 0;
			for (int i = 0; i < 4; i++)
			{
				if (pbt[i].vaild)
				{
					p[k] = pbt[i];
					k++;
				}
				if (k >= 2)
					break;
				if (pat[i].vaild)
				{
					p[k] = pat[i];
					k++;
				}
				if (k >= 2)
					break;
			}
			if (k == 1)
			{
				n = n * directVec(B->position - A->position);
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[0].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			else if (k == 2)
			{
				n = n * directVec(B->position - A->position);
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[0].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[1].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			else
				return false;
		}
		//����
		else if (B->collideType == BOX)
		{
			pat[0] = lineCrossPoint(Aa, Ab, Bb, Bd);
			pat[1] = lineCrossPoint(Aa, Ab, Ba, Bc);
			pat[2] = lineCrossPoint(Ac, Ad, Bb, Bd);
			pat[3] = lineCrossPoint(Ac, Ad, Ba, Bc);

			pbt[0] = lineCrossPoint(Ba, Bb, Aa, Ac);
			pbt[1] = lineCrossPoint(Bc, Bd, Aa, Ac);
			pbt[2] = lineCrossPoint(Ba, Bb, Ab, Ad);
			pbt[3] = lineCrossPoint(Bc, Bd, Ab, Ad);

			int k = 0;
			for (int i = 0; i < 4; i++)
			{
				if (pbt[i].vaild)
				{
					p[k] = pbt[i];
					k++;
				}
				if (k >= 2)
					break;
				if (pat[i].vaild)
				{
					p[k] = pat[i];
					k++;
				}
				if (k >= 2)
					break;
			}
			if (k == 1)
			{
				n = n * directVec(B->position - A->position);
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[0].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			else if (k == 2)
			{
				n = n * directVec(B->position - A->position);
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[0].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				list.push_back(Intersect(maxDistance < 0, maxDistance, n, p[1].point, vec3(0, 0, 0), vec3(0, 0, 0), A, B));
				res = true;
			}
			else
				return false;
		}
		return res;
	}
}
