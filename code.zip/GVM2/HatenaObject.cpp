#include "HatenaObject.h"
#include"State.h"
void HatenaObject::elementStartState(Intersect* intersectInfo, Object* obj2, ClassifyList* clist)
{
	if (abs(intersectInfo->n.y) && obj2->velocity.y > 0)
	{
		//Ҫ����һ����״̬ȫ����ɺ�ſ��Խ����µ�״̬

		if (!this->inClassify(BEHAVE_DEVICE))
		{
			state = MoveUp::Instance();
			clist->add(this, BEHAVE_DEVICE);
		}
	}
}

bool HatenaObject::stateRun()
{
	state = state->stateRun(this);
	if (typeid(*state) == typeid(Stop))
		return false;
	return true;
}
