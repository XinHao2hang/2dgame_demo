#include "map.h"
map* map::tMap;
double map::px;
double map::py;