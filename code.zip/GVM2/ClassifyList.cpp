#include "ClassifyList.h"
#include"Object.h"
#include"GameBlockObject.h"
ClassifyList::ClassifyList()
{
	for (int i = 0; i < 6; i++)
	{
		head[i] = new Object;
		tail[i] = head[i];
	}
}
void ClassifyList::add(Object* obj, int classify)
{
	if (names.find(obj->objName) == names.end())
	{
		//�����µĽ��
		tail[0]->next[0] = obj;
		tail[0]->next[0]->prior[0] = tail[0];
		tail[0] = tail[0]->next[0];
		//tail[0]->data = obj;
		names[obj->objName] = obj;
	}
	if (classify == 0)
		return;
	//�޸�ָ��
	//���������
	if (names[obj->objName]->next[classify] != nullptr && names[obj->objName]->prior[classify] != nullptr)
		return;
	tail[classify]->next[classify] = names[obj->objName];
	tail[classify]->next[classify]->prior[classify] = tail[classify];
	tail[classify] = tail[classify]->next[classify];
}

void ClassifyList::del(Object* node, int classify)
{
	delList.push_back(std::make_tuple(node, classify));
}

void ClassifyList::del(std::string name, int classify)
{
	if (names.find(name) == names.end())
		return;
	delList.push_back(std::make_tuple(names[name], classify));
}

bool ClassifyList::noUse(Object* node)
{
	
	return node->next[1] == nullptr && node->prior[1] == nullptr &&
		node->next[2] == nullptr && node->prior[2] == nullptr &&
		node->next[3] == nullptr && node->prior[3] == nullptr &&
		node->next[4] == nullptr && node->prior[4] == nullptr;
}

void ClassifyList::deleteNode(Object* del, int classify)
{
	if (del->prior[classify] == nullptr && del->next[classify] == nullptr)
		return;
	if (del->prior[classify] != head[classify] && del->next[classify] != nullptr)
	{
		del->prior[classify]->next[classify] = del->next[classify];
		del->next[classify]->prior[classify] = del->prior[classify];
	}
	else if (del->prior[classify] == head[classify] && del->next[classify] == nullptr)
	{
		tail[classify] = head[classify];
		head[classify]->next[classify] = nullptr;
	}
	else if (del->prior[classify] == head[classify])
	{
		head[classify]->next[classify] = del->next[classify];
		del->next[classify]->prior[classify] = head[classify];
	}
	//λ�ڽ�β
	else if (del->next[classify] == nullptr)
	{
		del->prior[classify]->next[classify] = del->next[classify];

		tail[classify] = del->prior[classify];
	}
	del->next[classify] = nullptr;
	del->prior[classify] = nullptr;

	if (classify == 0)
	{
		names.erase(((GameBlockObject*)del)->objName);
		delete del;
	}
}

void ClassifyList::recycle()
{
	std::vector<Object*>destoryList;
	for (unsigned int i = 0; i < delList.size(); i++)
	{
		auto delElement = delList[i];
		Object* del = std::get<0>(delElement);
		int classify = std::get<1>(delElement);
		deleteNode(del, classify);
		if (noUse(del))
		{
			if (find(destoryList.begin(), destoryList.end(), del) == destoryList.end())
				destoryList.push_back(del);
		}
	}
	for (unsigned int i = 0; i < destoryList.size(); i++)
	{
		deleteNode(destoryList[i], 0);
	}
	delList.clear();
}

Object* ClassifyList::begin(int c)
{
	if (head[c] == tail[c])
		return tail[c];
	return head[c]->next[c];
}

Object* ClassifyList::end(int c)
{
	return tail[c];
}
