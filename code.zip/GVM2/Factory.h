#pragma once
#include"RedBrickWallObject.h"
#include"StoneGroundObject.h"
#include"RedBrickChipObject.h"
#include"SkyBkObject.h"
#include"HatenaObject.h"
#include"QuesEmptyObject.h"
#include"CoinFlyObject.h"
class Factory
{
	std::string className;
public:
	
	Factory(){}
	Factory(std::string _name):className(_name) {}
	GameBlockObject* operator()(std::string name, glm::vec3 size, glm::vec3 pos, glm::vec3 a)
	{
		if (className == "RedBrickWallObject")
			return new RedBrickWallObject(name,size,pos,a);
		else if (className == "StoneGroundObject")
			return new StoneGroundObject(name, size, pos, a);
		else if (className == "GameBlockObject")
			return new GameBlockObject(name, size, pos, a);
		else if (className == "RedBrickChipObject")
			return new RedBrickChipObject(name, size, pos, a);
		else if (className == "SkyBkObject")
			return new SkyBkObject(name, size, pos, a);
		else if (className == "HatenaObject")
			return new HatenaObject(name, size, pos, a);
		else if (className == "QuesEmptyObject")
			return new QuesEmptyObject(name, size, pos, a);
		else if (className == "CoinFlyObject")
			return new CoinFlyObject(name, size, pos, a);
		
		
	}
	~Factory() {}
};

