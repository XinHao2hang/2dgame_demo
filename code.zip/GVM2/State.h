#pragma once
#include"Devices.h"
class GameBlockObject;
class State
{
public:
	State() {}
	virtual State* stateRun(GameBlockObject*obj) = 0;
	static State* Instance() { return nullptr; }
	~State() {}
};

class Stop :public State
{
public:
	Stop(){}
	virtual State* stateRun(GameBlockObject* obj) { return this; }
	static State* Instance()
	{
		static Stop stop;
		return &stop;
	}
	~Stop() {}
};

class MoveDown :public State
{
public:
	
	MoveDown(){}
	virtual State* stateRun(GameBlockObject* obj);
	static State* Instance()
	{
		static MoveDown movedown;
		return &movedown;
	}
	~MoveDown() {}
};

class MoveUp:public State
{
public:
	
	MoveUp() {};
	virtual State* stateRun(GameBlockObject* obj);
	static State* Instance() 
	{
		static MoveUp moveup;
		return &moveup;
	}
	~MoveUp() {};
};

class Break :public State
{
public:
	Break() {}
	virtual State* stateRun(GameBlockObject* obj);
	static State* Instance()
	{
		static Break moveup;
		return &moveup;
	}
	~Break() {}
};

class QuesChangeEmpty : public State
{
public:
	QuesChangeEmpty(){}
	virtual State* stateRun(GameBlockObject* obj);
	static State* Instance()
	{
		static QuesChangeEmpty empty;
		return &empty;
	}
	~QuesChangeEmpty() {}
};

class CoinFly : public State
{
public:
	CoinFly() {}
	virtual State* stateRun(GameBlockObject* obj);
	static State* Instance()
	{
		static CoinFly fly;
		return &fly;
	}
	~CoinFly() {}
};