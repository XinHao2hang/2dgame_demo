#pragma once
#include"BaseObject.h"

enum CollideType
{
	NONE = 0,

	TOP = 1 << 0,
	BOTTOM = 1 << 1,
	LEFT = 1 << 2,
	RIGHT = 1 << 3,

	BOX = TOP | BOTTOM | LEFT | RIGHT,

	TOPLINE = TOP,
	BOTTOMLINE = BOTTOM,
	LEFTLINE = LEFT,
	RIGHTLINE = RIGHT,

	DOUBLE_XLINE = TOP | BOTTOM,
	DOUBLE_YLINE = LEFT | RIGHT,

	CTOP = LEFT | RIGHT | BOTTOM,
	CBOTTOM = LEFT | RIGHT | TOP,
	CLEFT = RIGHT | TOP | BOTTOM,
	CRIGHT = LEFT | TOP | BOTTOM,

	LLEFTTOP = LEFT | TOP,
	LRIGHTTOP = RIGHT|TOP,
	LLEFTBOTTOM = LEFT|BOTTOM,
	LRIGHTBOTTOM = RIGHT|BOTTOM
};
class PhyObject : virtual public BaseObject
{
public:
	glm::vec3 BottomRight = glm::vec3(0,-2000,0);
	glm::vec3 startPos;
	//����
	int collideType = NONE;	
	//���ٶ�
	glm::vec3 acceleration = glm::vec3(0,0,0);
	//�Ǽ��ٶ�
	//glm::vec3 angle_acceleration = glm::vec3(0, 0, 0);
	//�ٶ�
	glm::vec3 velocity = glm::vec3(0,0,0);
	//���ٶ�
	glm::vec3 angle_velocity = glm::vec3(0, 0, 0);
	//����
	float mass = 10.0;
	float invMass = 1/10.0f;
	glm::vec3 backPos;
	//�趨��̬��Ϣ
	void setPosture(glm::vec3 _pos, glm::vec3 _angle)
	{
		position = _pos;
		startPos = position;
		angle = _angle;
	}
	void run()
	{
		velocity += acceleration;
		position += velocity;
		if (fabs(velocity.x) > 10)
			velocity.x = fabs(velocity.x)/velocity.x *10;
		if (fabs(velocity.y) > 10)
			velocity.y = fabs(velocity.y) / velocity.y * 10;
	
		angle += angle_velocity;
		acceleration = glm::vec3(0,0,0);
		angle_velocity = glm::vec3(0, 0, 0);
		startPos = position;
	}
	void addForce(glm::vec3 force)
	{
		if(mass!=0)
		acceleration += force;
	}
	void back()
	{
		position += backPos;
		backPos = glm::vec3(0,0,0);
	}
	PhyObject(){}
	virtual ~PhyObject() {}
};

