#include "ControlObj.h"



ControlObj::ControlObj()
{
}


ControlObj::~ControlObj()
{
}
