#pragma once
#include"GameBlockObject.h"
class StoneGroundObject : public GameBlockObject
{
public:
	StoneGroundObject()
	{
		//��������
		texture = "bricks";
		setAnim(textureCtrl.readFromFile("wall0.ti"));
	}
	StoneGroundObject(std::string name,glm::vec3 size, glm::vec3 pos, glm::vec3 a) :GameBlockObject(name, size, pos, a)
	{
		//��������
		texture = "bricks";
		setAnim(textureCtrl.readFromFile("wall0.ti"));
	}
	virtual void elementStartState(Intersect* intersectInfo, Object* obj2, ClassifyList* clist) {}
	virtual bool stateRun() { return false; }
	virtual ~StoneGroundObject()
	{

	}
};

