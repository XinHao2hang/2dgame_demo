#pragma once
#include"GameBlockObject.h"
class HatenaObject : public GameBlockObject
{
public:
	HatenaObject() {}
	HatenaObject(std::string name, glm::vec3 size, glm::vec3 pos, glm::vec3 a) :GameBlockObject(name, size, pos, a)
	{
		//��������
		texture = "hatena";
		setAnim(textureCtrl.readFromFile("hatena.ti"));
		//���ö�������
		setAnimIndexArray({0,0,0,0,0,1,2,3});
	}
	virtual void elementStartState(Intersect* intersectInfo, Object* obj2, ClassifyList* clist);
	virtual bool stateRun();
	virtual ~HatenaObject() {}
};

