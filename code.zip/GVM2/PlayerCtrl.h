#pragma once
#include"GameObj.h"
#include"OperateBase.h"
#include <GLFW/glfw3.h>

#include<iostream>
#include<vector>

#include<queue>
using namespace std;

static double curX, curY;
static bool left_button_click = false;
static bool left_button_release = false;
static bool left_button_press = false;
class CtlMessage
{
public:
	CtlMessage(GameObj* r, OperateBase* op) :receive(r), opt(op) {}
	GameObj* receive;
	OperateBase* opt;
};
class LookAroundOpt :public OperateBase
{
	//�ⲿ�����������Ϣ
	vector<GameObj*> objs;
public:
	LookAroundOpt(vector<GameObj*>& _objs):objs(_objs) {}
	virtual bool run(ControlObj* obj)
	{
		//���㵱ǰ��������������֮��ľ����ϵ
	}
};
class PlayerCtrl
{
public:
	//�������һ����Ϣ���У�ÿ�ζ��ռ�������Ϣ
	/*��Ϣ�ĸ�ʽ:��Ϣ������(����ָ��)����Ϣ�е�ָ�����*/
	queue<CtlMessage*>message;
	vector<GameObj*> ctrlObjects;
	//��������������ɿ�
	vec3 curClickPos;
	vec3 curReleasePos;
	vec3 curPressPos;
	//��ѡ�ķ�Χ
	vec3 rectLeftTop, rectRightBottom;
	void setSelectRect(vec3 lt, vec3 rb)
	{
		rectLeftTop = lt;
		rectRightBottom = rb;
	}
	static void curse_poscallback(GLFWwindow* window, double x, double y)
	{
		curX = x;
		curY = y;
	}
	static void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
	{
		if (action == GLFW_PRESS)
		{
			switch (button)
			{
			case GLFW_MOUSE_BUTTON_LEFT:
				left_button_click = true;
				break;
			case GLFW_MOUSE_BUTTON_MIDDLE:
				cout << "Mosue middle button clicked!";
				break;
			case GLFW_MOUSE_BUTTON_RIGHT:
				cout << "Mosue right button clicked!";
				break;
			default:
				return;
			}
		}
		if (action == GLFW_RELEASE)
		{
			switch (button)
			{
			case GLFW_MOUSE_BUTTON_LEFT:
				left_button_release = true;
				break;
			case GLFW_MOUSE_BUTTON_MIDDLE:
				cout << "Mosue middle button clicked!";
				break;
			case GLFW_MOUSE_BUTTON_RIGHT:
				cout << "Mosue right button clicked!";
				break;
			default:
				return;
			}
		}
		return;
	
	}
	void mouseButton()
	{
		//����������������һϵ�в�������
		if (left_button_click)
		{
			cout << curX << "," << curY << endl;
			left_button_click = false;
			left_button_press = true;
			curClickPos = vec3(curX,curY,0);
			message.push(new CtlMessage(ctrlObjects[0], new testWalkOpt(vec3(curX*2-800,800-curY*2,0))));
		}
		if (left_button_release)
		{
			cout << curX << "," << curY << endl;
			left_button_release = false;
			curReleasePos = vec3(curX, curY, 0);
			left_button_press = false;
			
			//for (int i = 0; i < ctrlObjects.size(); i++)
			//{
			//	vec3 pos = ctrlObjects[i]->position;
			//	//˵���ڿ�ѡ��
			//	if (pos.x > rectLeftTop.x && pos.x<rectRightBottom.x && pos.y>rectRightBottom.y && pos.y < rectLeftTop.y)
			//	{
			//		message.push(new CtlMessage(ctrlObjects[i], new testWalkOpt(vec3(curX * 2 - 800, 800 - curY * 2, 0))));
			//	}
			//}
			curPressPos = curClickPos;
		}
		if (left_button_press)
		{
			curPressPos = vec3(curX, curY, 0);
			
		}
	}
	void run()
	{
		//�ַ���Ϣ
		if (!message.empty())
		{
			CtlMessage* msg = message.front();
			msg->receive->receiveOperate(msg->opt);
			message.pop();
		}

		//��������
		for (int i = 0; i < ctrlObjects.size(); i++)
		{
			ctrlObjects[i]->runOperate();
		}
	}
	PlayerCtrl();
	PlayerCtrl(GLFWwindow * window)
	{
		glfwSetCursorPosCallback(window, curse_poscallback);
		glfwSetMouseButtonCallback(window, mouse_button_callback);
	}
	~PlayerCtrl();
};
