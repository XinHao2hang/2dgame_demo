#pragma once
#include<unordered_map>
#include<string>
#include"ClassifyList.h"
#include"Intersect.h"
static glm::vec3 directVec(glm::vec3 v)
{
	if (v.x != 0)
		v.x = v.x / fabs(v.x);
	if (v.y != 0)
		v.y = v.y / fabs(v.y);
	if (v.z != 0)
		v.z = v.z / fabs(v.z);
	return v;
}
enum ModuleID
{
	NO_DEVICE = 0,
	DRAW_DEVICE,
	PHY_DEVICE,
	COLLIDE_DEVICE,
	BEHAVE_DEVICE,
	ANIM_DEVICE,
};

class BaseObject;
class Module
{
public:
	//����洢�б�
	static std::vector<std::string> objects_name;
	static std::vector<Intersect> intersect_list;
	static ClassifyList CList;
	void recycle()
	{
		CList.recycle();
	}

	Module(){}
	virtual void add(Object* object);
	~Module() {}
};
//
