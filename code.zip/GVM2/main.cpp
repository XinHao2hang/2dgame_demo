#include<iostream>

#include"OpenGLDevice.h"
#include"SingleMesh.h"
#include"SingleShader.h"
#include"NullTexture.h"
#include"BaseObject.h"
#include"SingleTexture.h"
#include"textureMesh.h"
#include"map.h"
#include<cmath>
#include"arrayTexture.h"
#include<thread>
#include"devices.h"
#include<ctime>
#include"Factory.h"
#include"controlObject.h"
#include"Player.h"
using namespace std;

int main()
{
	Devices::draw.addMesh("rect", textureMesh<GLuint>().loadMesh("rect.vtt"));
	Devices::draw.addShader("rect", SingleShader<GLuint>().loadShader({ "rect.vsta","rect.fsta" }));
	Devices::draw.addTexture("bricks", arrayTexture<GLuint>().loadTexture({ "M1_Field_plain.png" }));
	Devices::draw.addTexture("sky", arrayTexture<GLuint>().loadTexture({ "M1_DV_sky.png" }));
	Devices::draw.addTexture("hatena", arrayTexture<GLuint>().loadTexture({ "hatena//0.png","hatena//1.png","hatena//2.png","hatena//3.png" }));
	Devices::draw.addTexture("coin", arrayTexture<GLuint>().loadTexture({ "coin//0.png"}));

	GameBlockObject* sky = Factory("SkyBkObject")("yutyhg", glm::vec3(2000, 2000, 0), glm::vec3(0, 0, 0.9), glm::vec3(0,0,0));
	sky->set({ &Devices::module,&Devices::draw });

	GameBlockObject* obj = Factory("RedBrickWallObject")("12", glm::vec3(80, 80, 0), glm::vec3(0, 96, 0), glm::vec3(0,0,0));

	GameBlockObject* obj1 = Factory("RedBrickWallObject")("123", glm::vec3(80, 80, 0), glm::vec3(0, 0, 0), glm::vec3(0,0,0));
	GameBlockObject* obj2 = Factory("RedBrickWallObject")("select", glm::vec3(80, 80, 0), glm::vec3(0, 0, 0), glm::vec3(0,0,0));
	obj2->set({ &Devices::module,&Devices::draw });

	GameBlockObject* obj3 = Factory("HatenaObject")("12345", glm::vec3(80, 80, 0), glm::vec3(0, 0, 0), glm::vec3(0,0,0));
	int aaa = sizeof(GameBlockObject);
	controlObject* obj4 = (controlObject*)Factory("StoneGroundObject")("123425", glm::vec3(50, 50, 0), glm::vec3(-640, -640, 0),glm::vec3(0,0,0));
	obj4->mass = 10;
	obj4->invMass = 1 / 10.0f;
	obj4->set({&Devices::module,&Devices::collide,&Devices::draw,&Devices::physic});
	obj4->collideType = BOX;
	map game_map;
	game_map.addElement(0, 1, obj);
	game_map.addElement(5, 2, obj1);
	game_map.addElement(0, 2, obj3);

	game_map.set({&Devices::module,&Devices::draw,&Devices::collide});
	game_map.select = obj2;
	game_map.setInput(Devices::draw.window);
	
	Player player(Devices::draw.window);
	player.setPlayer(obj4);	
	srand((int)time(0));
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	//glEnable(GL_DEPTH_TEST);
	while (1)
	{
		
		Devices::module.recycle();
		game_map.setBufferList();

		Devices::collide.Collide();
		Devices::physic.Physic();
		Devices::physic.back();
		Devices::draw.draw();
		Devices::physic.run();
		Devices::anime.run();
		
		Devices::behavior.run();
		//ɾ��Ҫͳһ����
		glfwSwapInterval(1);
		glfwPollEvents();
	}
	return 0;
}