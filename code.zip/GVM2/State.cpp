#include "State.h"
#include"GameBlockObject.h"
#include"Factory.h"
#include"Object.h"
#include"map.h"
#include<ctime>
State* MoveUp::stateRun(GameBlockObject* obj)
{
	//������ʺ�ש��,Ҫ������Ӧ��Ч��
	
	if (abs(obj->position.y - obj->startPos.y) <= 20)
	{
		obj->position.y+=5;
		obj->zoom += 0.05;
	}
	else
	{
		if (typeid(*obj) == typeid(HatenaObject))
		{
			//�������
			GameBlockObject* flyCoin = Factory("CoinFlyObject")("fly", glm::vec3(80, 80, 0), obj->position, glm::vec3(0, 0, 0));
			flyCoin->objName = to_string((int)flyCoin) + "fly";
			//flyCoin->BottomRight.y
			//���ü��ٶ�
			flyCoin->acceleration = glm::vec3(0, 7, 0);
			flyCoin->mass = 10;
			flyCoin->invMass = 1 / 10.0;
			flyCoin->angle_velocity = glm::vec3(0,60,0);
			//����Ԫ��
			Devices::module.add(flyCoin);
			Devices::draw.add(flyCoin);
			Devices::physic.add(flyCoin);
			flyCoin->BottomRight.y = obj->position.y;
			obj->position.z = 0.3;
		}
		return MoveDown::Instance();
	}
	return this;
}

State* MoveDown::stateRun(GameBlockObject* obj)
{
	if (obj->position.y - obj->startPos.y >= 0)
	{
		obj->position.y-=5;
		obj->zoom -= 0.05;
	}
	else
	{
		obj->zoom = glm::vec3(1, 1, 1);
		obj->position.y = obj->startPos.y;
		if (typeid(*obj) == typeid(HatenaObject))
			return QuesChangeEmpty::Instance();
		return Stop::Instance();
	}
	return this;
}

State* Break::stateRun(GameBlockObject* obj)
{
	//��ԭʼ��ɾ��
	int name[4];
	GameBlockObject* objs[4];
	for (int i = 0; i <4; i++)
	{
		name[i] = rand() % 9999999;
		objs[i] = Factory("RedBrickChipObject")(to_string(name[i]) + "asdf", glm::vec3(80, 80, 0), obj->position, glm::vec3(0,0,0));
		objs[i]->mass = 10;
		objs[i]->invMass = 1 / 10.0;
		objs[i]->angle_velocity = glm::vec3(0,0,1);
		objs[i]->objName = to_string((int)objs[i])+"break";
		Devices::module.add(objs[i]);
		Devices::draw.add(objs[i]);
		Devices::physic.add(objs[i]);
	}
	objs[0]->acceleration = vec3(3, 5, 0);
	objs[1]->acceleration = vec3(-3, 5, 0);
	objs[2]->acceleration = vec3(4, 10, 0);
	objs[3]->acceleration = vec3(-4, 10, 0);

	Devices::module.CList.del(obj->objName, PHY_DEVICE);
	Devices::module.CList.del(obj->objName, DRAW_DEVICE);
	Devices::module.CList.del(obj->objName, COLLIDE_DEVICE);
	Devices::module.CList.del(obj->objName, BEHAVE_DEVICE);
	obj->mapPtr->deleteElement(obj->i,obj->j);

	//�����µĿ�
	return Stop::Instance();
}

State* QuesChangeEmpty::stateRun(GameBlockObject* obj)
{
	int name = rand() % 9999999;
	GameBlockObject* empty = Factory("QuesEmptyObject")(to_string(name) + "asdfq", glm::vec3(80, 80, 0), obj->position, glm::vec3(0,0,0));
	empty->mass = 0;
	empty->invMass = 0;
	empty->objName = to_string((int)empty) + "empty";
	int i = obj->i;
	int j = obj->j;

	obj->mapPtr->deleteElement(obj->i, obj->j);
	obj->mapPtr->addElement(i, j,empty);
	
	return Stop::Instance();
}

State* CoinFly::stateRun(GameBlockObject* obj)
{

	return nullptr;
}
