#include "Object.h"
#include"devices.h"
void Object::lifeEnd()
{
	if (position.y < BottomRight.y)
	{
		Devices::module.CList.del(this->objName, PHY_DEVICE);
		Devices::module.CList.del(this->objName, DRAW_DEVICE);
		Devices::module.CList.del(this->objName, COLLIDE_DEVICE);
		Devices::module.CList.del(this->objName, BEHAVE_DEVICE);
		Devices::module.CList.del(this->objName, ANIM_DEVICE);
	}
}
