#pragma once
#include"PhyObject.h"
#include"DrawObject.h"
#include"MapObj.h"
using namespace std;
using namespace glm;
class State;
class Object :public PhyObject,public DrawObject,public MapObj
{
public:
	//ǰһ��
	Object* prior[6] = { 0 };
	//��һ��
	Object* next[6] = { 0 };
	Object() 
	{
		mesh = "rect";
		meshRange = std::make_tuple(0, 6);
	}	
	//���Ӵ���ģ��
	virtual void set(std::vector<Module*> modules)
	{
		for (unsigned long i = 0; i < modules.size(); i++)
		{
			modules[i]->add(this);
		}
	}
	bool inClassify(int classify)
	{
		return next[classify] != nullptr || prior[classify] != nullptr;
	}
	virtual void lifeEnd();
	virtual void elementStartState(Intersect* intersectInfo, Object* obj2, ClassifyList* clist) {}
	virtual bool stateRun() { return false; }
	virtual ~Object() {}
};

