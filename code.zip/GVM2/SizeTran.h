#pragma once
#include<glm/glm.hpp>
using namespace glm;
class SizeTran
{

public:
	SizeTran() {}
	static vec3 convert(vec3 point,vec3 scale)
	{
		return vec3(point.x*scale.x,point.y*scale.y,point.z*scale.z);
	}
	~SizeTran() {}
};

