#pragma once
#include"SizeTran.h"
#include"textureIniFile.h"
#include<string>
#include<vector>
using namespace std;
class spiritObj : public SingleObj
{
	
public:
	spiritObj() {}
	spiritObj(string _shader, string _texture, string _mesh, int _mstart, int _mend, vec3 _position, glm::vec3 _zoom):
		SingleObj(_shader, _texture, _mesh,_mstart, _mend, _position, _zoom){}
	//״̬��
	vector<int> stateGroup;
	//������
	vector<vector<int>> anims;
	//����֡
	vector<vec3> frames;
	//ÿ֡�Ĵ�С
	vec2 frameSize;
	//��ǰ��ʾ֡
	vec3 frameNow;
	//��ǰ״̬
	int state = 0, step = 0;
	//����״̬��
	void setStateGroup(vector<int> g)
	{
		stateGroup = g;
	}
	//�����л�����
	void loopAnim()
	{
		frameNow = frames[anims[state][step]];
		//���ﶯ���ӳ�
		static int time = 0;
		if (time == 15)
		{
			time = 0;
			step = (step + 1) % anims[state].size();
		}
		if (step == anims[state].size()-1)
		{
			//��������Զ�ת��״̬��ȥ�Զ�ת��
			if (stateGroup[state] != -1)
			{
				state = stateGroup[state];
				step = 0;
			}
		}
		++time;
		
	}
	virtual void draw(GLuint shaderID)
	{
		//���Ŷ���
		loopAnim();

		//������״̬��ת������

		unsigned int transformLoc = glGetUniformLocation(shaderID, "transform");
		unsigned int zoomLoc = glGetUniformLocation(shaderID, "zoom");
		unsigned int positionLoc = glGetUniformLocation(shaderID, "position");
		unsigned int texZoom = glGetUniformLocation(shaderID, "texZoom");
		unsigned int texPos = glGetUniformLocation(shaderID, "texPos");
		//�����Ժ�Ҫ�����ⲿ������ĽǶȱ仯ֵ����������������˵������ת��
		glUniformMatrix4fv(transformLoc, 1, GL_FALSE, glm::value_ptr(tran));
		glUniform3f(zoomLoc, zoom.x, zoom.y, zoom.z);
		vec3 pos = SizeTran::convert(position, vec3(1.0 / 800, 1.0 / 800, 1.0/800));
		glUniform3f(positionLoc, pos.x, pos.y, pos.z);
		glUniform3f(texPos, frameNow.x, frameNow.y, frameNow.z);
		glUniform2f(texZoom, frameSize.x, frameSize.y);
		glDrawElements(GL_TRIANGLES, endMeshIndex, GL_UNSIGNED_INT, (void*)(sizeof(GLuint) * startMeshIndex));
	}
	virtual void readTextureIni(string fileName)
	{
		//��ȡ����������Ϣ
		textureIniFile ini;
		ini.readFile(fileName);
		frameSize = ini.getVec2("Size");
		frames = ini.getVec3s("frames");
		anims = ini.getVecVis("anims");
		vec2 texture_size = ini.getVec2("texture_size");
		//��һ������
		for (int i = 0; i < frames.size(); i++)
		{
			frames[i].x /= texture_size.x;
			frames[i].y /= texture_size.y;
			frames[i].y = 1.0 - frames[i].y;
		}
		frameSize.x /= texture_size.x;
		frameSize.y /= texture_size.y;
	}
	static Object* instance(string filename)
	{
		ifstream file(filename);
		string shader;
		string mesh;
		string texture;
		int ms, me;
		int sizeX, sizeY;
		string animFile;
		vector<int>status;
		string name;
		file >> shader;
		file >> texture;
		file >> mesh;
		file >> ms;
		file >> me;
		file >> sizeX;
		file >> sizeY;
		file >> animFile;
		int t;
		file >> t;
		status.push_back(t);
		file >> name;
		spiritObj * res = new spiritObj(shader, texture, mesh, ms, me, vec3(0, 0, 0), vec3(sizeX, sizeY,0));
		res->readTextureIni(animFile);
		res->setStateGroup(status);
		res->objName = name;
		return res;
	}
	
	~spiritObj() {}
};

