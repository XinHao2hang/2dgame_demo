#pragma once
#include"Module.h"
#include"GameBlockObject.h"
class BehaviorActivate : public Module
{
public:
	virtual void run()
	{
		for (Object* i = CList.begin(BEHAVE_DEVICE); i != nullptr; i = i->next[BEHAVE_DEVICE])
		{
			if (!i->stateRun())
			{
				CList.del(i,BEHAVE_DEVICE);
			}
		}
	}
};

