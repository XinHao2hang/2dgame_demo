#pragma once
#include"GameBlockObject.h"
class RedBrickChipObject : public GameBlockObject
{
public:
	RedBrickChipObject(){}
	RedBrickChipObject(std::string name, glm::vec3 size, glm::vec3 pos, glm::vec3 a) :GameBlockObject(name, size, pos, a)
	{
		//��������
		texture = "bricks";
		setAnim(textureCtrl.readFromFile("wallchip.ti"));
	}

	virtual ~RedBrickChipObject() {}
};

