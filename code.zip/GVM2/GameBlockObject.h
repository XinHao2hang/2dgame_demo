#pragma once
#include"Object.h"
#include"TextureCtrl.h"
class State;
class GameBlockObject : public Object
{
public:
	
	GameBlockObject()
	{
		shader = "rect";
		
	}
	GameBlockObject(std::string name, glm::vec3 size, glm::vec3 pos, glm::vec3 a)
	{
		objName = name;
		r = size;
		position = pos;
		angle = a;
		shader = "rect";
		mass = 0;
		invMass = 0;
		
	}
	//��ɫ������
	unsigned int transformLoc;
	unsigned int zoomLoc;
	unsigned int positionLoc;
	unsigned int texZoom;
	unsigned int texPos;

	virtual void shaderVar(GLuint shaderID)
	{
		transformLoc = glGetUniformLocation(shaderID, "transform");
		zoomLoc = glGetUniformLocation(shaderID, "zoom");
		positionLoc = glGetUniformLocation(shaderID, "position");
		texZoom = glGetUniformLocation(shaderID, "texZoom");
		texPos = glGetUniformLocation(shaderID, "texPos");
	}

	virtual void draw(GLuint shaderID)
	{
		//�����Ժ�Ҫ�����ⲿ������ĽǶȱ仯ֵ����������������˵������ת��
		tran = glm::rotate(tran, glm::radians(angle.z), glm::vec3(0.0, 0.0, 1.0));
		tran = glm::rotate(tran, glm::radians(angle.y), glm::vec3(0.0, 1.0, 0.0));
		glUniformMatrix4fv(transformLoc, 1, GL_FALSE, glm::value_ptr(tran));
		glUniform2f(texZoom, nowTexSize.x, nowTexSize.y);
		glUniform3f(texPos, nowTexPos.x, nowTexPos.y, nowTexPos.z);
		glUniform3f(zoomLoc, r.x*zoom.x, r.y*zoom.y, r.z*zoom.z);
		vec3 pos = SizeTran::convert(position, vec3(1.0 / 800, 1.0 / 800, 1));
		glUniform3f(positionLoc, pos.x, pos.y, pos.z);
		glDrawElements(GL_TRIANGLES, get<1>(meshRange), GL_UNSIGNED_INT, (void*)(sizeof(GLuint) * get<0>(meshRange)));
	}
	State* state;
	//Ԫ��
	virtual void elementStartState(Intersect* intersectInfo,Object*obj2, ClassifyList*clist);
	virtual bool stateRun();
	virtual ~GameBlockObject() {}
};

