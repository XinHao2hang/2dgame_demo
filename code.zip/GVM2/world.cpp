#include "world.h"



world::world()
{
}

void world::run()
{
	for (int i = 0; i < rigids.size(); i++)
		rigids[i]->update(0.5);
	for (int i = 0; i < rigids.size(); i++)
	{
		for (int j = i + 1; j < rigids.size(); j++)
		{
			//������ײ��Ϣ
			collide::collideCalc(rigids[i], rigids[j]);
		}
	}
}

void world::put(Rigid* obj)
{
	rigids.push_back(obj);
}


world::~world()
{
}
