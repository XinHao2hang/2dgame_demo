#pragma once
#include"ControlObj.h"
class OperateBase
{
public:
	virtual bool run(ControlObj* obj)
	{
		//��һЩʲô����
		return false;
	}
	OperateBase();
	~OperateBase();
};

class WalkOpt :public OperateBase
{
	int a = 50;
public:
	virtual bool run(ControlObj* obj)
	{
		if (a > 0)
		{
			obj->position.x -= 0.01;
			cout << "aa" << endl;
			a--;
			return true;
		}
		return false;
	}
};
class testWalkOpt :public OperateBase
{
	vec3 pos;
public:
	testWalkOpt(vec3 _pos) :pos(_pos) {}
	virtual bool run(ControlObj* obj)
	{
		vec3 n = normalize(pos - obj->position);
		float len = length(pos - obj->position);
		if (len >= 1)
		{
			obj->position += n * 0.0005f;
			return true;
		}

		return false;
	}


};