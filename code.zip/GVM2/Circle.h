#pragma once
#include"Rigid.h"
class Circle : public Rigid
{
public:
	//�뾶
	float radius = 0;
	Circle();

	Circle(float _mass, vec3 _center, vec3 _position, float _radius)
	{
		radius = _radius;
		//type = CIRCLE;
		mass = _mass;
		position = _position;
		float i = (2.0 / 5.0) * mass * radius * radius;
		I = mat3(vec3(i, 0, 0), vec3(0, i, 0), vec3(0, 0, i));
		Iv = inverse(I);
		//��������Ŀ
		axisNum = 0;
		vertexNum = 2;
	}
	float getRadius() { return radius; }
	vec3 getRadiusVec(vec3 axis) { return axis * 2.0f* radius; }
	virtual void update(float time);
	//��ȡ����
	virtual vec3 getVertex(int index,vec3 axis) 
	{ 
		if (index == 0)
			return getRadiusVec(axis);
		if(index == 1)
			return -getRadiusVec(axis);
		return vec3(0,0,0);
	}
	~Circle();
};

