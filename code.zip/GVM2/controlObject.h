#pragma once
#include"StoneGroundObject.h"
class controlObject : public StoneGroundObject
{
public:
	controlObject(){}
	//controlObject(string name, string _shader, string _texture, string _mesh, tuple<vec3, int, int> _meshInfo) :BaseObject(name,_shader,_texture,_mesh,_meshInfo){}
	void keyUp()
	{
		acceleration += vec3(0, 15, 0);
	}
	void keyLeft()
	{
		acceleration += vec3(-2, 0, 0);
	}
	void keyRight()
	{
		acceleration += vec3(2, 0, 0);
	}
	~controlObject() {}
};

