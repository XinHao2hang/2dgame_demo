#include "CoinFlyObject.h"

//void CoinFlyObject::lifeEnd()
//{
//
//}
