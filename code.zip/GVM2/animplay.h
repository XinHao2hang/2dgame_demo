#pragma once
#include"Module.h"
class Object;
class animplay : public Module
{
	double accumulator = 0;
	double lastTime = 0;
public:
	unsigned long clock = 0;
	animplay(){}
	virtual void run();
	virtual void add(Object* object)
	{
		CList.add(object, ANIM_DEVICE);
	}
	~animplay() {}
};

