#pragma once
#include "Shader.h"
#include<fstream>
#include<iostream>
#include<vector>
using namespace std;
template<class SHADER>
class SingleShader :public Shader<SHADER>
{
public:
	GLuint shaderProgram;
	virtual SHADER loadShader(vector<string> fileNames)
	{
		GLchar *codeVS=nullptr,*codeFS=nullptr;
		try
		{
			//vs��ɫ��
			GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
			//��ȡ�ļ�
			ifstream fin(fileNames[0].c_str(), ios::app);
			if (fin.fail())
			{
				cout << "vs file load error filename:" << fileNames[0] << endl;
				throw -1;
			}
			fin.seekg(0, ios_base::end);
			int size = (int)fin.tellg();
			fin.seekg(0, ios_base::beg);
			codeVS = new GLchar[size];
			memset(codeVS,0,size);
			fin.read(codeVS, size);
			//����
			glShaderSource(vertexShader, 1, &codeVS, NULL);
			glCompileShader(vertexShader);
			fin.close();
			if (!ErrorLog(GL_COMPILE_STATUS, vertexShader))
				throw -1;		//fs��ɫ��
			GLuint fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
			//��ȡ�ļ�
			fin.open(fileNames[1].c_str(), ios::app);
			if (fin.fail())
			{
				cout << "fs file load error filename:" << fileNames[1] << endl;
				throw -1;
			}
			fin.seekg(0, ios_base::end);
			size = (int)fin.tellg();
			fin.seekg(0, ios_base::beg);
			codeFS = new GLchar[size];
			memset(codeFS, 0, size);
			fin.read(codeFS, size);
			glShaderSource(fragmentShader, 1, &codeFS, NULL);
			glCompileShader(fragmentShader);
			fin.close();
			if (!ErrorLog(GL_COMPILE_STATUS, fragmentShader))
				throw -1;

			//��������
			shaderProgram = glCreateProgram();
			glAttachShader(shaderProgram, vertexShader);
			glAttachShader(shaderProgram, fragmentShader);
			glLinkProgram(shaderProgram);
			if (ErrorLog(GL_LINK_STATUS, shaderProgram))
				throw -1;
		
			glDeleteShader(vertexShader);
			glDeleteShader(fragmentShader);
			throw - 1;
		}
		catch (int s)
		{
			//�ͷ���ʱ�ռ�
			delete[] codeVS;
			delete[] codeFS;
			return shaderProgram;
		}
	}
	bool ErrorLog(unsigned long FLAG, GLuint program)
	{
		int success;
		char infoLog[512] = { 0 };
		//���Ӵ�����
		if (FLAG == GL_LINK_STATUS)
		{
			glGetProgramiv(program, FLAG, &success);
			if (!success)
			{
				glGetProgramInfoLog(program, 512, NULL, infoLog);
				std::cout << "ERROR::LINK\n" << infoLog << std::endl;
				return false;
			}
		}
		//���������
		else
		{
			glGetShaderiv(program, FLAG, &success);
			if (!success)
			{
				glGetShaderInfoLog(program, 512, NULL, infoLog);
				std::cout << "ERROR::SHADER\n" << infoLog << std::endl;
				return false;
			}
		}
		return true;
	}
	SingleShader() {}
	~SingleShader() {}
};

