#pragma once
#include<glm/glm.hpp>
class Object;
class Intersect
{
public:
	Intersect() {}
	Intersect(bool isI, float _distance, glm::vec3 _n,glm::vec3 _point, glm::vec3 _rA,glm::vec3 _rB, Object *_A, Object*_B) :
		isIntersect(isI), distance(_distance), n(_n),rA(_rA),rB(_rB),A(_A),B(_B)
	{
		point = _point;
	}
	//�ཻ���
	float distance = 0;
	//�ཻ���
	bool isIntersect = false;
	//���淨����
	glm::vec3 n = glm::vec3(0,0,0);
	//��ײ�������ĵ���İ뾶
	glm::vec3 rA = glm::vec3(0, 0, 0), rB = glm::vec3(0, 0, 0);
	//����
	Object* A;
	Object* B;
	int pointNum = 0;
	float invMassNormal = 0;
	float bias = 0;
	float Pn = 0;
	//��ײ��
	glm::vec3 point = glm::vec3(0,0,0);
	~Intersect() {}
};

