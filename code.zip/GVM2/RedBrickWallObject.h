#pragma once
#include"GameBlockObject.h"
class RedBrickWallObject :public GameBlockObject
{
public:
	RedBrickWallObject(){}
	RedBrickWallObject(std::string name, glm::vec3 size, glm::vec3 pos, glm::vec3 a):GameBlockObject(name,size,pos,a)
	{
		//��������
		texture = "bricks";
		setAnim(textureCtrl.readFromFile("wall1.ti"));
	}
	virtual ~RedBrickWallObject() {}
};

