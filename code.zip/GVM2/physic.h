#pragma once
#include"Module.h"
#include"Object.h"
#include<algorithm>
static vec3 vecMax(vec3 a, vec3 b)
{
	vec3 res;
	res.x = a.x > b.x ? a.x : b.x;
	res.y = a.y > b.y ? a.y : b.y;
	return res;
}
class physic : public Module
{
public:
	physic() {}
	virtual void add(Object* object)
	{
		CList.add(object,PHY_DEVICE);
	}
	void back()
	{
		for (Object* i = CList.begin(PHY_DEVICE); i != nullptr; i = i->next[PHY_DEVICE])
				i->back();

	}
	virtual void run()
	{
		//���н��
		for (Object* i = CList.begin(PHY_DEVICE); i != nullptr; i = i->next[PHY_DEVICE])
		{
			i->run();
			i->addForce(vec3(0, -0.3, 0));
		}
	}

	virtual void Physic()
	{
		for (unsigned long i = 0; i < intersect_list.size(); i++)
		{
			PhyObject* A = intersect_list[i].A;
			PhyObject* B = intersect_list[i].B;
			intersect_list[i].invMassNormal = 1.0f / (A->invMass + B->invMass);
			intersect_list[i].bias = -0.2f * (std::min(0.0, intersect_list[i].distance - 0.001)) * 0;

			if (A->mass != 0)
				A->backPos = -vecMax(abs(A->backPos), abs(intersect_list[i].n * (fabs(intersect_list[i].distance) + 0.5f))) * intersect_list[i].n;
			if (B->mass != 0)
				B->backPos = -vecMax(abs(B->backPos), abs(intersect_list[i].n * (fabs(intersect_list[i].distance) + 0.5f))) * intersect_list[i].n;
			/*A->velocity -= A->invMass * Pn;
			B->velocity += B->invMass * Pn;*/
		}
		//������ײ
		for (unsigned long j = 0; j < 10; j++)
			for (unsigned long i = 0; i < intersect_list.size(); i++)
			{

				PhyObject* A = intersect_list[i].A;
				PhyObject* B = intersect_list[i].B;

				for (int k = 0; k < 1; k++)
				{
					vec3 dv = B->velocity - A->velocity;
					float vn = dot(dv, intersect_list[i].n);

					float dP = intersect_list[i].invMassNormal * (-vn + intersect_list[i].bias);

					float Pn0 = intersect_list[i].Pn;
					intersect_list[i].Pn = std::max(Pn0 + dP, 0.0f);
					dP = intersect_list[i].Pn - Pn0;

					vec3 Pn = dP * intersect_list[i].n;


					A->velocity -= A->invMass * Pn;
					B->velocity += B->invMass * Pn;
				}
			}
		intersect_list.clear();
	}
	~physic() {}
};

