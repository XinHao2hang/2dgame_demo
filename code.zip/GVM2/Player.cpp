#include "Player.h"

controlObject* Player::player;
