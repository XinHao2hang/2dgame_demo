#pragma once
#include<vector>
#include<string>
#include"Module.h"
#include"Object.h"
using namespace std;
class DrawDevice : public Module
{
public:
	//��ɫ��
	unordered_map<string, GLuint> shaders;
	//vector<GLuint> shaders;
	//����
	unordered_map<string, GLuint> meshs;
	//����
	unordered_map<string, GLuint> textures;	
	//�����б�
	//vector<string>drawList;
	DrawDevice() {};
	//��ʼ��
	virtual void init() {};
	//����
	virtual void draw() {};
	//����
	virtual void add(Object* object) {};
	//ɾ��
	virtual void del() {};
	//������Դ
	void addShader(string name,GLuint s)
	{
		shaders[name]=s;
	}
	void addMesh(string name,GLuint m)
	{
		meshs[name]=m;
	}
	void addTexture(string name,GLuint t)
	{
		textures[name] = t;
	}

	~DrawDevice() {};
};

