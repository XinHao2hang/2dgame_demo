#include "Rigid.h"



Rigid::Rigid()
{
}


void Rigid::updateVelocity(float time)
{
	velocity += force * time;
}

void Rigid::updatePosition(float time)
{
	position += velocity * time;// +force * time * time * 0.05f;
}

void Rigid::update(float time)
{
	updatePosition(time);
	updateVelocity(time);
	//�޸���ת����
	angular += angular_velocity;
	tran = EulerAngle::getMat(angular);
	force = vec3(0, 0, 0);
}

Rigid::~Rigid()
{
}
