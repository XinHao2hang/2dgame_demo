#include "DrawObject.h"
TextureCtrl DrawObject::textureCtrl;