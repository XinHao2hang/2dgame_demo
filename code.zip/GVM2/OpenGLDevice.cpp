#include "OpenGLDevice.h"
#include"Object.h"
void OpenGLDevice::mainDraw()
{
	static string nowShader, nowTexture, nowMesh;

	for (Object* i = CList.begin(DRAW_DEVICE); i != nullptr; i = i->next[DRAW_DEVICE])
	{
		//��ȡԪ��
		Object* drawObj = i;
		if (nowShader != drawObj->shader)
		{
			nowShader = drawObj->shader;
			glUseProgram(shaders[nowShader]);
		}
		if (nowTexture != drawObj->texture)
		{
			nowTexture = drawObj->texture;
			glBindTexture(GL_TEXTURE_2D_ARRAY, textures[nowTexture]);
		}
		if (nowMesh != drawObj->mesh)
		{
			nowMesh = drawObj->mesh;
			glBindVertexArray(meshs[nowMesh]);
		}
		drawObj->draw(shaders[nowShader]);
		drawObj->lifeEnd();
	}
}
