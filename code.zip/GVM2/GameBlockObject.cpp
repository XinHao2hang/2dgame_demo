#include "GameBlockObject.h"
#include"Intersect.h"
#include"State.h"
void GameBlockObject::elementStartState(Intersect* intersectInfo, Object* obj2, ClassifyList* clist)
{
	if (abs(intersectInfo->n.y) && obj2->velocity.y > 0)
	{
		//Ҫ����һ����״̬ȫ����ɺ�ſ��Խ����µ�״̬
		
		if (!this->inClassify(BEHAVE_DEVICE))
		{
			//state = MoveUp::Instance();
			state = Break::Instance();
			clist->add(this, BEHAVE_DEVICE);
		}
	}
}

bool GameBlockObject::stateRun()
{
	state = state->stateRun(this);
	if (typeid(*state) == typeid(Stop))
		return false;
	return true;
}
