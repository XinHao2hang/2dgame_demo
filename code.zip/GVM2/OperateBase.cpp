#include "OperateBase.h"



OperateBase::OperateBase()
{
}


OperateBase::~OperateBase()
{
}
