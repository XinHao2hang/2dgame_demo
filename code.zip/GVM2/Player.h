#pragma once
#include"OpenGLDevice.h"
#include"controlObject.h"
#include<iostream>
class Player
{
public:
	GLFWwindow* window = nullptr;
	Player(GLFWwindow* window)
	{
		glfwSetKeyCallback(window, key_callback);
	}
	void setPlayer(controlObject* object)
	{
		player = object;
	}
	static controlObject* player;
	static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
	{
		if (action != GLFW_PRESS)
			return;
		switch (key)
		{
		case GLFW_KEY_UP:
			player->keyUp();
			break;
		case GLFW_KEY_LEFT:
			player->keyLeft();
			break;
		case GLFW_KEY_RIGHT:
			player->keyRight();
			break;
		default:
			break;
		}
	}
	~Player() {}
};

