#version 330 core
out vec4 FragColor;
void main()
{
    FragColor = vec4(1.0f, 0.5f, 0.2f, 1.0f);
	ivec2 coord = ivec2(gl_FragCoord.x,gl_FragCoord.y);
	if((coord.x+coord.y)%2==0)
		discard;
}