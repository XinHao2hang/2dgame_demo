#pragma once
#include"Mesh.h"
#include<fstream>
#include<vector>
#include"SizeTran.h"
using namespace std;
template<class MESH>
class SingleMesh :public Mesh<MESH>
{
public:
	//��������ָ��
	vector<GLfloat> data;
	//�����±�ָ��
	vector<GLuint> index;
	//����ָ��
	GLuint VAO;

	//���ض���
	virtual MESH loadMesh(string fileName)
	{
		ifstream fin(fileName);
		if (!fin.is_open())
			return -1;
		//���ض�������
		int count = 0;
		fin >> count;
		float zoom = 0;
		fin >>zoom;
		for (int i = 0; i < count ;i++)
		{
			GLfloat x=0,y=0,z=0;
			fin >> x;
			fin >> y;
			fin >> z;
			vec3 pt = SizeTran::convert(vec3(x,y,z),vec3(1.0/800,1.0/800,0));
			x = pt.x;
			y = pt.y;
			z = pt.z;
			data.push_back(x * zoom);
			data.push_back(y * zoom);
			data.push_back(z * zoom);
		}
		fin >> count;
		for (int i = 0; i < count; i++)
		{
			GLuint t = 0;
			fin >> t;
			index.push_back(t);
		}
		//���붥��ָ��
		glGenVertexArrays(1, &VAO);
		glBindVertexArray(VAO);
		GLuint VBO=0;
		//��������
		glGenBuffers(1, &VBO);
		glBindBuffer(GL_ARRAY_BUFFER, VBO);
		glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat)*data.size(), data.data(), GL_STATIC_DRAW);
		GLuint EBO=0;
		//�±�
		glGenBuffers(1, &EBO);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(GLuint)*index.size(), index.data(), GL_STATIC_DRAW);
		//�����ʽ
		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
		glEnableVertexAttribArray(0);
		
		return VAO;
	}
	SingleMesh() {};
	~SingleMesh() {};
};

