#pragma once
#include"GameBlockObject.h"
class QuesEmptyObject : public GameBlockObject
{
public:
	QuesEmptyObject(){}
	QuesEmptyObject(std::string name, glm::vec3 size, glm::vec3 pos, glm::vec3 a) :GameBlockObject(name, size, pos, a)
	{
		//��������
		texture = "bricks";
		setAnim(textureCtrl.readFromFile("quesempty.ti"));
	}
	virtual void elementStartState(Intersect* intersectInfo, Object* obj2, ClassifyList* clist) {}
	virtual bool stateRun() { return false; }
	~QuesEmptyObject() {}
};

