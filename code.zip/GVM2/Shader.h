#pragma once
#include <glad/glad.h>
#include <string>
using namespace std;
template<class SHADER>
class Shader
{
public:
	virtual SHADER loadShader(vector<string> fileNames) = 0;
	Shader() {};
	~Shader() {};
};

