#pragma once
class map;
class MapObj
{
public:
	MapObj(){}
	static map* mapPtr;
	bool inMap = false;
	int i = 0, j = 0;
	~MapObj(){}
};

