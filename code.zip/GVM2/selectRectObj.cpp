#include "selectRectObj.h"



selectRectObj::selectRectObj()
{
}


selectRectObj::~selectRectObj()
{
}
