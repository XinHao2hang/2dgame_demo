#pragma once
#include"SingleTexture.h"

template<class TEXTURE>
class arrayTexture : public SingleTexture<TEXTURE>
{
public:
	arrayTexture() {}
	virtual TEXTURE loadTexture(vector<string> filename)
	{
		int width, height;
		//��ȡͼ���ļ�����
		unsigned char* image = SOIL_load_image(filename[0].c_str(), &width, &height, 0, SOIL_LOAD_RGBA);
		SOIL_free_image_data(image);
		glGenTextures(1, &this->texture);
		glBindTexture(GL_TEXTURE_2D_ARRAY, this->texture);

		glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
		glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);

		glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

		glTexImage3D(GL_TEXTURE_2D_ARRAY, 0, GL_RGBA, width, height, filename.size(), 0, GL_BGRA, GL_UNSIGNED_BYTE, NULL);

		for (int i = 0; i < filename.size(); i++)
		{
			unsigned char* image = SOIL_load_image(filename[i].c_str(), &width, &height, 0, SOIL_LOAD_RGBA);
			//��������
			glTexSubImage3D(GL_TEXTURE_2D_ARRAY, 0, 0, 0, i, width, height, 1, GL_BGRA, GL_UNSIGNED_BYTE, image);
			SOIL_free_image_data(image);
		}

		glGenerateMipmap(GL_TEXTURE_2D_ARRAY);
		glBindTexture(GL_TEXTURE_2D_ARRAY, 0);
		return this->texture;
	}
	~arrayTexture() {}
};

