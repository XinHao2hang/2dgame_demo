#pragma once
#include<string>
#include<tuple>
#include<glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include"Module.h"
#include"SizeTran.h"
#include"TextureCtrl.h"
class BaseObject
{
public:
	BaseObject() {}
	//λ��
	glm::vec3 position = glm::vec3(0, 0, 0);
	//ת��
	glm::vec3 angle = glm::vec3(0,0,0);
	//�뾶
	glm::vec3 r;
	//��������
	std::string objName;
	virtual ~BaseObject(){}
};

