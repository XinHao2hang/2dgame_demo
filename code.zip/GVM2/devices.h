#pragma once
#include"Module.h"
#include"physic.h"
#include"BehaviorActivate.h"
#include"collide.h"
#include"animplay.h"
#include"OpenGLDevice.h"
class Devices
{
public:
	static Module module;
	static OpenGLDevice draw;
	static collide collide;
	static physic physic;
	static BehaviorActivate behavior;
	static animplay anime;
};

