#pragma once
#include"SingleObj.h"
#include"SizeTran.h"
class selectRectObj :public SingleObj
{
public:
	float x, y, width, height;
	virtual void draw(GLuint shaderID)
	{
		//position = vec3(x,y,0);
		//zoom = vec3(width,height,0);
		unsigned int transformLoc = glGetUniformLocation(shaderID, "transform");
		unsigned int zoomLoc = glGetUniformLocation(shaderID, "zoom");
		unsigned int positionLoc = glGetUniformLocation(shaderID, "position");
		//�����Ժ�Ҫ�����ⲿ������ĽǶȱ仯ֵ����������������˵������ת��
		//tran = glm::rotate(tran, glm::radians(0.1f), glm::vec3(0.0, 0.0, 1.0));
		//static vec3 posit = vec3(0.5, 0, 0);
		glUniformMatrix4fv(transformLoc, 1, GL_FALSE, glm::value_ptr(tran));
		glUniform3f(zoomLoc, zoom.x, zoom.y, zoom.z);
		vec3 pos = SizeTran::convert(position, vec3(1.0 / 800, 1.0 / 800, 1.0 / 800));
		glUniform3f(positionLoc, pos.x, pos.y, pos.z);
		glDrawElements(GL_LINE_LOOP, endMeshIndex, GL_UNSIGNED_INT, (void*)(sizeof(GLuint)* startMeshIndex));
		//glDrawElements(GL_TRIANGLES, endMeshIndex, GL_UNSIGNED_INT, (void*)(sizeof(GLuint) * startMeshIndex));
	}
	selectRectObj();
	selectRectObj(int _shader, int _texture, int _mesh, int _mstart, int _mend, vec3 _position, glm::vec3 _zoom):
		SingleObj(_shader, _texture, _mesh, _mstart, _mend, _position, _zoom) 
	{

	}
	~selectRectObj();
};

