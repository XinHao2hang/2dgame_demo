#include "MapObj.h"
map* MapObj::mapPtr = nullptr;