#pragma once

#include <glad/glad.h>
#include<string>
#include<vector>
using namespace std;
template<class TEXTURE>
class Texture
{
public:
	TEXTURE texture;
	virtual TEXTURE loadTexture(vector<string> filename)=0;
	Texture() {}
	~Texture() {}
};

